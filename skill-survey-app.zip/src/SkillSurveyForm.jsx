import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

const skillCategories = [
  "FrontEnd Development",
  "Database Management",
  "Ui/UX Development",
  "Hardware & Networking",
  "Production Support",
  "Cloud Computing",
  "Program Management",
  "Business Analyst",
  "Project Management",
  "QA/ Testing",
  "Desktop Support",
  "BackEnd Development",
  "Research & Development",
  "Cyber Security",
  "Graphic Designing",
  "Mobile Development",
  "AI/ ML",
  "Others (Please Specify)"
];

export default function SkillSurveyForm() {
  const [name, setName] = useState("");
  const [selectedSkills, setSelectedSkills] = useState([]);
  const [ratings, setRatings] = useState({});
  const [customOtherSkill, setCustomOtherSkill] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setIsAdmin(params.get("admin") === "true");
  }, []);

  const toggleSkill = (skill) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter((s) => s !== skill));
      const updatedRatings = { ...ratings };
      delete updatedRatings[skill];
      setRatings(updatedRatings);
      if (skill === "Others (Please Specify)") setCustomOtherSkill("");
    } else if (selectedSkills.length < 3) {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const handleRatingChange = (skill, value) => {
    setRatings({ ...ratings, [skill]: value });
  };

  const handleSubmit = async () => {
    const processedSkills = selectedSkills.map((skill) => {
      const name = skill === "Others (Please Specify)" ? customOtherSkill : skill;
      return {
        skill: name,
        rating: ratings[skill] || ""
      };
    });

    const submission = {
      name,
      skills: processedSkills
    };

    try {
      const response = await fetch("https://api.sheetbest.com/sheets/dd49b51d-9d82-4b20-9bad-964f1d1854ab", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(submission)
      });
      if (response.ok) {
        alert("Response submitted successfully.");
      } else {
        alert("Submission failed.");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Error occurred during submission.");
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-10 space-y-6 bg-[#0a1a2f] text-white p-6 rounded-xl shadow-xl">
      <Card className="bg-[#112544] border-none">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-xl font-semibold text-white">IT Skill Self-Assessment</h2>
          <div>
            <Label className="text-white">Full Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter your full name" className="bg-white text-black" />
          </div>
          <div>
            <Label className="text-white">Select Top 3 Areas of Expertise</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {skillCategories.map((skill) => (
                <Button
                  key={skill}
                  variant={selectedSkills.includes(skill) ? "default" : "outline"}
                  onClick={() => toggleSkill(skill)}
                  disabled={!selectedSkills.includes(skill) && selectedSkills.length >= 3}
                >
                  {skill}
                </Button>
              ))}
            </div>
          </div>

          {selectedSkills.length > 0 && (
            <div className="space-y-4">
              <Label className="text-white">Rate Your Expertise</Label>
              {selectedSkills.map((skill) => (
                <div key={skill} className="space-y-2">
                  {skill === "Others (Please Specify)" && (
                    <Input
                      value={customOtherSkill}
                      onChange={(e) => setCustomOtherSkill(e.target.value)}
                      placeholder="Enter your custom skill"
                      className="bg-white text-black"
                    />
                  )}
                  <p className="font-medium text-white">{skill === "Others (Please Specify)" ? customOtherSkill || skill : skill}</p>
                  <Select onValueChange={(value) => handleRatingChange(skill, value)}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Select rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          )}

          <Button onClick={handleSubmit} className="mt-4">Submit</Button>
        </CardContent>
      </Card>

      {isAdmin && (
        <div className="bg-[#1c3557] p-4 rounded-md">
          <h3 className="text-lg font-semibold">Admin View</h3>
          <p>To access submissions, go to your connected Google Sheet or Sheet.best dashboard.</p>
        </div>
      )}
    </div>
  );
}