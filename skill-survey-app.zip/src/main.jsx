import React from 'react'
import ReactDOM from 'react-dom/client'
import SkillSurveyForm from './SkillSurveyForm.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SkillSurveyForm />
  </React.StrictMode>,
)